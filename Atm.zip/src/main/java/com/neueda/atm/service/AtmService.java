package com.neueda.atm.service;

import com.neueda.atm.dto.Withdraw;

public interface AtmService {

    public String withDraw(Withdraw withdraw);

}
